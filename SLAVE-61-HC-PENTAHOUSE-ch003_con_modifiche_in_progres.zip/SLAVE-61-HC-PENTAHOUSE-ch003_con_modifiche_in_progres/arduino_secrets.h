#define SECRET_SSID     "Bulgari055"
#define SECRET_PASS     "Bulgari@Bulgari055"     

char sonoio[2] = {'6', '1'};
//CANALE 090
